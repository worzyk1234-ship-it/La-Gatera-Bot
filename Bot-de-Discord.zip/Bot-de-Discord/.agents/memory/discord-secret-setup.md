---
name: Discord secret setup
description: Replit-specific behavior when saving a Discord bot token as a project secret.
---

If saving `DISCORD_TOKEN` fails through the secure secret form, retry the same request before changing the bot or asking for the token in chat. A later retry can save it successfully.

**Why:** The first secret-save attempt failed even though the second attempt succeeded with the same requested key.

**How to apply:** Keep Discord credentials out of source files and use the secure secret flow; after the secret is added, restart the bot workflow so it receives the new environment value.