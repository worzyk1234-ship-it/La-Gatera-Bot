---
name: Giveaway persistence
description: Persistence boundary for the Discord bot's giveaway system.
---

Giveaway state is intentionally persisted in a local JSON file because the bot currently runs as one long-lived workflow. Active giveaways and participants must be restored after a workflow restart.

**Why:** A restart should not erase entries or leave an active giveaway without its buttons and automatic ending task.

**How to apply:** Keep restoration and automatic scheduling coupled to bot startup. If the bot is ever scaled to multiple processes or containers, move this state to shared storage before doing so.